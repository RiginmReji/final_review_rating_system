import re
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, parsers, generics
from django.utils import timezone
from .models import Review, ReviewImage
from .serializers import ReviewSerializer, ReviewImageSerializer
from .dl_model import get_rating_and_sentiment

# -------------------------------
# Review Validation
# -------------------------------
def is_valid_review(text: str) -> bool:
    if not text or len(text.strip()) < 5:
        return False
    if not re.search(r"[A-Za-z]", text):
        return False
    if re.fullmatch(r"[\d\W_]+", text):
        return False
    clean_text = text.strip()
    if re.search(r"[bcdfghjklmnpqrstvwxyz]{5,}", clean_text.lower()):
        return False
    if re.search(r"[A-Za-z]+\d+|\d+[A-Za-z]+", clean_text):
        return False
    if not re.search(r"\s", clean_text) and len(clean_text) > 6:
        vowels = len(re.findall(r"[aeiouAEIOU]", clean_text))
        consonants = len(re.findall(r"[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]", clean_text))
        if consonants > vowels * 2:
            return False
    return True

# -------------------------------
# Create Review
# -------------------------------
class ReviewAPIView(APIView):
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def post(self, request, *args, **kwargs):
        text = request.data.get("text", "")
        images = request.FILES.getlist("images")

        if not is_valid_review(text):
            return Response({"error": "Invalid or meaningless review."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            predicted = get_rating_and_sentiment(text)

            review = Review.objects.create(
                text=text,
                predicted_rating=predicted["predicted_rating"],
                sentiment=predicted["sentiment"],
                created_at=timezone.now()
            )

            for img in images:
                ReviewImage.objects.create(review=review, image=img)

            serializer = ReviewSerializer(review)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# -------------------------------
# List Reviews
# -------------------------------
class ReviewListAPIView(APIView):
    def get(self, request, *args, **kwargs):
        reviews = Review.objects.all().order_by('-created_at')
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

# -------------------------------
# Update Review
# -------------------------------
class ReviewUpdateAPIView(APIView):
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]

    def put(self, request, pk, *args, **kwargs):
        try:
            review = Review.objects.get(pk=pk)
        except Review.DoesNotExist:
            return Response({"error": "Review not found"}, status=status.HTTP_404_NOT_FOUND)

        text = request.data.get("text", "")
        images = request.FILES.getlist("images")
        remove_images = request.data.getlist("remove_images")

        if not is_valid_review(text):
            return Response({"error": "Invalid or meaningless review."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            predicted = get_rating_and_sentiment(text)
            review.text = text
            review.predicted_rating = predicted["predicted_rating"]
            review.sentiment = predicted["sentiment"]
            review.updated_at = timezone.now()
            review.save()

            if remove_images:
                ReviewImage.objects.filter(review=review, id__in=remove_images).delete()

            for img in images:
                ReviewImage.objects.create(review=review, image=img)

            serializer = ReviewSerializer(review)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# -------------------------------
# Delete Review
# -------------------------------
class ReviewDeleteAPIView(generics.DestroyAPIView):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
