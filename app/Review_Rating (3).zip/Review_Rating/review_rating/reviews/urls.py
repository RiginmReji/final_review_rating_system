from django.urls import path
from .views import (
    ReviewAPIView,
    ReviewListAPIView,
    ReviewUpdateAPIView,
    ReviewDeleteAPIView,
)

urlpatterns = [
    path("review/", ReviewAPIView.as_view(), name="review-create"),
    path("reviews/", ReviewListAPIView.as_view(), name="review-list"),
    path("review/update/<int:pk>/", ReviewUpdateAPIView.as_view(), name="review-update"),
    path("review/delete/<int:pk>/", ReviewDeleteAPIView.as_view(), name="review-delete"),
]
