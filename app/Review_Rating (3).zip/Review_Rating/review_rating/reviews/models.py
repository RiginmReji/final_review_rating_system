from django.db import models

class Review(models.Model):
    text = models.TextField()
    predicted_rating = models.IntegerField()
    sentiment = models.CharField(max_length=10, blank=True)  # Positive / Negative / Neutral
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class ReviewImage(models.Model):
    review = models.ForeignKey(Review, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='review_images/')
