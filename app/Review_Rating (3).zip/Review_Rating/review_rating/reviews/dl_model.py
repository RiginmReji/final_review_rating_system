def get_rating_and_sentiment(text, max_len=100):
    """
    Returns predicted rating (1-5) and sentiment (Positive/Neutral/Negative)
    """
    import numpy as np
    import pickle
    import os
    from django.conf import settings
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    import tensorflow as tf

    MODEL_PATH = os.path.join(settings.BASE_DIR, "review_rating", "model_BiLSTM.h5")
    TOKENIZER_PATH = os.path.join(settings.BASE_DIR, "review_rating", "tokenizer.pkl")

    # Load model
    model = tf.keras.models.load_model(MODEL_PATH)
    with open(TOKENIZER_PATH, "rb") as f:
        tokenizer = pickle.load(f)

    # Tokenize
    seq = tokenizer.texts_to_sequences([text])
    padded_seq = pad_sequences(seq, maxlen=max_len, padding="post")

    pred_probs = model.predict(padded_seq, verbose=0)[0]
    predicted_rating = int(pred_probs.argmax() + 1)

    # Simple sentiment mapping
    if predicted_rating >= 4:
        sentiment = "Positive"
    elif predicted_rating == 3:
        sentiment = "Average"
    else:
        sentiment = "Negative"

    return {"predicted_rating": predicted_rating, "sentiment": sentiment}
