import os
import pickle
from django.conf import settings

# Paths to DL model and tokenizer
MODEL_PATH = os.path.join(settings.BASE_DIR, "review_rating", "model_BiLSTM.h5")
TOKENIZER_PATH = os.path.join(settings.BASE_DIR, "review_rating", "tokenizer.pkl")

# Global variables
model, tokenizer = None, None


def load_model_and_tokenizer():
    """
    Lazy-load the model and tokenizer to avoid heavy imports at Django startup.
    """
    global model, tokenizer

    if model is None:
        try:
            import tensorflow as tf  # moved inside to delay heavy import
            from tensorflow.keras.preprocessing.sequence import pad_sequences

            model = tf.keras.models.load_model(MODEL_PATH)
            print(" DL model loaded successfully")
        except Exception as e:
            print("Error loading DL model:", e)

    if tokenizer is None:
        try:
            with open(TOKENIZER_PATH, "rb") as f:
                tokenizer = pickle.load(f)
            print(" Tokenizer loaded successfully")
        except Exception as e:
            print(" Error loading tokenizer:", e)

    return model, tokenizer


def get_rating(review_text, max_len=100):
    """
    Predicts rating and sentiment score using the BiLSTM model and tokenizer.
    """
    import numpy as np
    from tensorflow.keras.preprocessing.sequence import pad_sequences

    model, tokenizer = load_model_and_tokenizer()

    if model is None or tokenizer is None:
        return {"predicted_rating": 3, "sentiment_score": 0.5}  # fallback

    try:
        # Tokenize and pad
        seq = tokenizer.texts_to_sequences([review_text])
        padded_seq = pad_sequences(seq, maxlen=max_len, padding="post")

        # Predict
        pred_probs = model.predict(padded_seq, verbose=0)[0]
        predicted_rating = int(pred_probs.argmax() + 1)
        sentiment_score = float(pred_probs[predicted_rating - 1])

        return {
            "predicted_rating": predicted_rating,
            "sentiment_score": round(sentiment_score, 3),
        }

    except Exception as e:
        print("Prediction error:", e)
        return {"predicted_rating": 3, "sentiment_score": 0.5}
