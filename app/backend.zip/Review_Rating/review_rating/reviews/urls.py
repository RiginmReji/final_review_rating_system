from django.urls import path
from .views import ReviewAPIView, ReviewListAPIView, ReviewDetailAPIView

urlpatterns = [
    path('review/', ReviewAPIView.as_view(), name='review-create'),        
    path('reviews/', ReviewListAPIView.as_view(), name='review-list'),     
    path('review/<int:pk>/', ReviewDetailAPIView.as_view(), name='review-detail'), 
]
