from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Review
from .serializers import ReviewSerializer
from .dl_model import get_rating  


class ReviewAPIView(APIView):
    """
    Create a review and get rating using DL model
    """

    def post(self, request, *args, **kwargs):
        text = request.data.get("text")

        if not text:
            return Response({"error": "Review text is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Predict rating and sentiment
        prediction = get_rating(text)
        rating = prediction["predicted_rating"]
        score = prediction["sentiment_score"]

        # Save review in DB
        review = Review.objects.create(
            text=text,
            predicted_rating=rating,
            sentiment_score=score,
        )

        serializer = ReviewSerializer(review)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class ReviewListAPIView(generics.ListAPIView):
    """
    List all reviews
    """
    queryset = Review.objects.all().order_by("-created_at")
    serializer_class = ReviewSerializer


class ReviewDetailAPIView(generics.RetrieveAPIView):
    """
    Get details of a single review by ID
    """
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
