import React, { useState } from "react";
import Header from "./components/Header";
import ReviewForm from "./components/ReviewForm";
import ReviewList from "./components/ReviewList";
import { Review } from "./types";
import "./App.css";

const App: React.FC = () => {
  const [newReview, setNewReview] = useState<Review | null>(null);

  // add filter state lifted to App
  const [sortBy, setSortBy] = useState<'date' | 'rating'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  return (
    <div className="app">
      {/* Amazon-style Header */}
      <Header />

      {/* Main Content - Two Column Layout */}
      <main className="main-content">
        <div className="container">
          <div className="two-column-layout">
            
            {/* Left Half - Review Analysis */}
            <div className="left-panel">
              <div className="analysis-section">
                <ReviewForm onNewReview={setNewReview} />
                
                {/* Latest Analysis Result */}
                {newReview && (
                  <div className="latest-analysis">
                    <div className="analysis-header">
                      <h3>Analysis Results</h3>
                    </div>
                    <div className="analysis-result">
                      <div className="analysis-row">
                        <span className="analysis-label">Your Review:</span>
                        <p className="analysis-text">"{newReview.text}"</p>
                      </div>
                      <div className="analysis-row">
                        <span className="analysis-label">Predicted Rating:</span>
                        <div className="rating-display">
                          <span className="rating-stars">
                            {"★".repeat(newReview.predicted_rating)}
                            {"☆".repeat(5 - newReview.predicted_rating)}
                          </span>
                          <span className="rating-number">({newReview.predicted_rating}/5)</span>
                        </div>
                      </div>
                      <div className="analysis-row">
                        <span className="analysis-label">Analysis:</span>
                        <div className="sentiment-display">
                          <span 
                            className="sentiment-text"
                            style={{ 
                              color: newReview.sentiment_score >= 0.6 ? '#007600' : 
                                     newReview.sentiment_score >= 0.4 ? '#b7aa00' : '#b12704' 
                            }}
                          >
                            {newReview.sentiment_score >= 0.8 ? 'Very Positive' :
                             newReview.sentiment_score >= 0.6 ? 'Positive' :
                             newReview.sentiment_score >= 0.4 ? 'Neutral' :
                             newReview.sentiment_score >= 0.2 ? 'Negative' : 'Very Negative'}
                          </span>
                          <span className="confidence-score">
                            ({(newReview.sentiment_score * 100).toFixed(1)}% confidence)
                          </span>
                        </div>
                      </div>
                      <div className="analysis-timestamp">
                        <small>Analyzed on {new Date(newReview.created_at).toLocaleString()}</small>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Right Half - Review Display */}
            <div className="right-panel">
              <div className="reviews-section">
                <div className="reviews-header">
                  <h2>Customer Reviews</h2>

                  {/* moved filters here */}
                  <div className="filter-controls">
                    <div className="filter-group">
                      <label htmlFor="sortBy">Sort by:</label>
                      <select
                        id="sortBy"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as 'date' | 'rating')}
                        className="filter-select"
                      >
                        <option value="date">Date</option>
                        <option value="rating">Rating</option>
                      </select>
                    </div>

                    <div className="filter-group">
                      <label htmlFor="sortOrder">Order:</label>
                      <select
                        id="sortOrder"
                        value={sortOrder}
                        onChange={(e) => setSortOrder(e.target.value as 'asc' | 'desc')}
                        className="filter-select"
                      >
                        <option value="desc">{sortBy === 'date' ? 'Newest First' : 'Highest First'}</option>
                        <option value="asc">{sortBy === 'date' ? 'Oldest First' : 'Lowest First'}</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="reviews-display">
                  <ReviewList newReview={newReview} sortBy={sortBy} sortOrder={sortOrder} />
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="amazon-footer">
        <div className="footer-content">
          <p>&copy;Amazon Review Analyzer.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;

