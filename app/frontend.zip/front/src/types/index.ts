export interface Review {
  id: number;
  text: string;
  predicted_rating: number;
  sentiment_score: number;
  created_at: string;
  reviewerName?: string;
}