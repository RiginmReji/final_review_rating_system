import axios from "axios";
import { Review } from './types';

export const api = axios.create({
  baseURL: "http://127.0.0.1:8000/api",
});

// API functions for reviews
export const submitReview = async (text: string): Promise<Review> => {
  const response = await api.post<Review>("/review/", { text });
  return response.data;
};

export const getReviews = async (): Promise<Review[]> => {
  const response = await api.get<Review[]>("/reviews/");
  return response.data;
};

export const getReview = async (id: number): Promise<Review> => {
  const response = await api.get<Review>(`/review/${id}/`);
  return response.data;
};
