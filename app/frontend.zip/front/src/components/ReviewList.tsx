import React, { useEffect, useState } from "react";
import { getReviews } from "../api";
import { Review } from '../types';
import Stars from "./Stars";
import './ReviewList.css';

interface ReviewListProps {
  newReview: Review | null;
  sortBy: 'date' | 'rating';
  sortOrder: 'asc' | 'desc';
}

const ReviewList: React.FC<ReviewListProps> = ({ newReview, sortBy, sortOrder }) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filteredReviews, setFilteredReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        const reviewsData = await getReviews();
        setReviews(reviewsData);
      } catch (err) {
        console.error('Error fetching reviews:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchReviews();
  }, [newReview]);
  useEffect(() => {
    let filtered = [...reviews];

    // Sort reviews using props sortBy/sortOrder
    filtered.sort((a, b) => {
      if (sortBy === 'date') {
        const dateA = new Date(a.created_at).getTime();
        const dateB = new Date(b.created_at).getTime();
        return sortOrder === 'desc' ? dateB - dateA : dateA - dateB;
      } else {
        return sortOrder === 'desc' 
          ? b.predicted_rating - a.predicted_rating 
          : a.predicted_rating - b.predicted_rating;
      }
    });

    setFilteredReviews(filtered);
  }, [reviews, sortBy, sortOrder]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getSentimentText = (score: number) => {
    if (score >= 0.8) return 'Very Positive';
    if (score >= 0.6) return 'Positive';
    if (score >= 0.4) return 'Neutral';
    if (score >= 0.2) return 'Negative';
    return 'Very Negative';
  };

  const getSentimentColor = (score: number) => {
    if (score >= 0.6) return '#007600';
    if (score >= 0.4) return '#b7aa00';
    return '#b12704';
  };

  return (
    <div className="review-list-container">
      <div className="reviews-content">
        {filteredReviews.length === 0 ? (
          <div className="no-reviews">
            <p>{reviews.length === 0 ? 'No reviews yet.' : 'No reviews match your filters.'}</p>
          </div>
        ) : (
          <div className="reviews-list">
            {filteredReviews.map((review, index) => (
              <div key={review.id} className="review-item">
                <div className="review-header">
                  <div className="reviewer-name">
                    {review.reviewerName || 'Anonymous Customer'}
                  </div>
                  <div className="review-stars">
                    <Stars rating={review.predicted_rating} />
                  </div>
                </div>
                
                <div className="review-content">
                  <p className="review-text">{review.text}</p>
                </div>
                
                <div className="review-footer">
                  <div className="review-date">Reviewed on {formatDate(review.created_at)}</div>
                  <div className="review-actions">
                    <span 
                      className="sentiment-score"
                      style={{ color: getSentimentColor(review.sentiment_score) }}
                    >
                      Sentiment score: {(review.sentiment_score * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};


export default ReviewList;
