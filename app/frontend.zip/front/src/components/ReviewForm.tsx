import React, { useState, useEffect } from "react";
import { submitReview, getReviews } from "../api";
import { Review } from '../types';
import Stars from "./Stars";
import './ReviewForm.css';

interface ReviewFormProps {
  onNewReview: (review: Review) => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ onNewReview }) => {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const reviewsData = await getReviews();
        setReviews(reviewsData);
      } catch (err) {
        console.error('Error fetching reviews:', err);
      }
    };
    fetchReviews();
  }, []);

  const calculateAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.predicted_rating, 0);
    return sum / reviews.length;
  };

  const getRatingDistribution = () => {
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    reviews.forEach(review => {
      const roundedRating = Math.round(review.predicted_rating);
      if (roundedRating >= 1 && roundedRating <= 5) {
        distribution[roundedRating as keyof typeof distribution]++;
      }
    });
    return distribution;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    
    setLoading(true);
    try {
      const review = await submitReview(text);
      onNewReview(review);
      setReviews(prev => [...prev, review]); 
      setText("");
      setShowModal(false); 
    } catch (err) {
      console.error(err);
      alert("Error submitting review");
    }
    setLoading(false);
  };

  return (
    <div className="review-form-container">
      {reviews.length > 0 && (
        <div className="average-rating-section">
          <h1>Customer Reviews</h1>
          <div className="average-rating-summary">
            <Stars rating={calculateAverageRating()} />
            <span className="average-number">
              {calculateAverageRating().toFixed(1)} out of 5
            </span>
            <span className="total-reviews">
              {reviews.length} global rating{reviews.length !== 1 ? 's' : ''}
            </span>
          </div>
          
          <div className="rating-distribution">
            {[5, 4, 3, 2, 1].map(star => {
              const distribution = getRatingDistribution();
              const count = distribution[star as keyof typeof distribution];
              const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
              
              return (
                <div key={star} className="rating-bar">
                  <span className="star-label">{star} star</span>
                  <div className="bar-container">
                    <div 
                      className="bar-fill" 
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                  <span className="count-label">{count}</span>
                </div>
              );
            })}
          </div>
          
          <div className="review-this-product">
            <h3>Review this product</h3>
            <p>Share your thoughts with other customers</p>
            <button 
              className="share-review-btn"
              onClick={() => setShowModal(true)}
            >
              Write a customer review
            </button>
          </div>
        </div>
      )}
      
      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Write a Customer Review</h2>
              <button 
                className="close-modal-btn"
                onClick={() => setShowModal(false)}
              >
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit} className="modal-review-form">
              <div className="form-group">
                <textarea
                  placeholder="Write your review here..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  required
                  rows={6}
                  className="modal-review-textarea"
                />
              </div>
              <div className="modal-actions">
                <button 
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="cancel-btn"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={loading || !text.trim()}
                  className="submit-modal-btn"
                >
                  {loading ? "Analyzing..." : "Submit Review"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewForm;
