import React from 'react';
import './Header.css';

const Header: React.FC = () => {
  return (
    <header className="amazon-header">
      <div className="header-inner">
        <div className="brand">
          <span className="brand-main">Amazon</span>
          <span className="brand-sub">Fine Food Review Analysis</span>
        </div>
      </div>
    </header>
  );
};

export default Header;