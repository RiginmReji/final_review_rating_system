import React, { useState } from "react";
import Header from "./components/Header";
import ReviewForm from "./components/ReviewForm";
import ReviewList from "./components/ReviewList";
import { Review } from "./types";
import "./App.css";

const App: React.FC = () => {
  const [newReview, setNewReview] = useState<Review | null>(null);

  // add filter state lifted to App
  const [sortBy, setSortBy] = useState<'date' | 'rating'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  return (
    <div className="app">
      {/* Amazon-style Header */}
      <Header />

      {/* Main Content - Two Column Layout */}
      <main className="main-content">
        <div className="container">
          <div className="two-column-layout">
            
            {/* Left Half - Review Analysis */}
            <div className="left-panel">
              <div className="analysis-section">
                <ReviewForm onNewReview={setNewReview} />
              </div>
            </div>
            
            {/* Right Half - Review Display */}
            <div className="right-panel">
              <div className="reviews-section">
                <div className="reviews-header">
                  <h2>Customer Reviews</h2>

                  {/* moved filters here */}
                  <div className="filter-controls">
                    <div className="filter-group">
                      <label htmlFor="sortBy">Sort by:</label>
                      <select
                        id="sortBy"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as 'date' | 'rating')}
                        className="filter-select"
                      >
                        <option value="date">Date</option>
                        <option value="rating">Rating</option>
                      </select>
                    </div>

                    <div className="filter-group">
                      <label htmlFor="sortOrder">Order:</label>
                      <select
                        id="sortOrder"
                        value={sortOrder}
                        onChange={(e) => setSortOrder(e.target.value as 'asc' | 'desc')}
                        className="filter-select"
                      >
                        <option value="desc">{sortBy === 'date' ? 'Newest First' : 'Highest First'}</option>
                        <option value="asc">{sortBy === 'date' ? 'Oldest First' : 'Lowest First'}</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="reviews-display">
                  <ReviewList newReview={newReview} sortBy={sortBy} sortOrder={sortOrder} />
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="amazon-footer">
        <div className="footer-content">
          <p>&copy;Amazon Review Analyzer.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;

