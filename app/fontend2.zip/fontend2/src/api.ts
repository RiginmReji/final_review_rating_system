import axios from "axios";
import { Review } from './types';

export const api = axios.create({
  baseURL: "http://127.0.0.1:8000/api",
});

export const BACKEND_ORIGIN = (() => {
  try {
    const url = new URL(api.defaults.baseURL || window.location.origin);
    // If baseURL contains '/api' at the end, remove it to get the origin
    return url.href.replace(/\/api\/?$/i, '').replace(/\/$/, '');
  } catch (e) {
    return (process.env.REACT_APP_BACKEND_ORIGIN || window.location.origin).replace(/\/$/, '');
  }
})();

// API functions for reviews
export const submitReview = async (text: string, images?: File[]): Promise<Review> => {
  // Always send FormData so backend receives a consistent multipart/form-data request.
  // Do NOT manually set the Content-Type header — letting the browser/axios set it
  // ensures the multipart boundary is included.
  const form = new FormData();
  form.append('text', text);
  if (images && images.length) {
    images.forEach(img => form.append('images', img));
  }
  const response = await api.post<Review>("/review/", form);
  return response.data;
};

export const getReviews = async (): Promise<Review[]> => {
  const response = await api.get<Review[]>("/reviews/");
  return response.data;
};

export const getReview = async (id: number): Promise<Review> => {
  const response = await api.get<Review>(`/review/${id}/`);
  return response.data;
};

// Update a review (text and optional images) - backend expects multipart/form-data
export const updateReview = async (id: number, text?: string, images?: File[], remove_image_ids?: number[]) : Promise<Review> => {
  const form = new FormData();
  if (typeof text !== 'undefined') form.append('text', text);
  if (images && images.length) {
    images.forEach(img => form.append('images', img));
  }
  if (remove_image_ids && remove_image_ids.length) {
    remove_image_ids.forEach(idVal => form.append('remove_images', String(idVal)));
  }

  // Let axios set the proper Content-Type (including boundary) automatically.
  const response = await api.put<Review>(`/review/update/${id}/`, form);
  return response.data;
};

export const deleteReview = async (id: number): Promise<void> => {
  await api.delete(`/review/delete/${id}/`);
};
