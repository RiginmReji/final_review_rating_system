import React from "react";

interface StarsProps {
  rating: number;
}

const Stars: React.FC<StarsProps> = ({ rating }) => {
  const stars = [1, 2, 3, 4, 5];
  return (
    <div className="stars">
      {stars.map((star) =>
        star <= rating ? (
          <span key={star} style={{ color: "#FFA41C" }}>★</span>
        ) : (
          <span key={star} style={{ color: "#ccc" }}>★</span>
        )
      )}
    </div>
  );
};

export default Stars;
