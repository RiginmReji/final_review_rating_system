import React, { useEffect, useState } from "react";
import { getReviews, updateReview, deleteReview, BACKEND_ORIGIN } from "../api";
import { Review } from '../types';
import Stars from "./Stars";
import './ReviewList.css';

interface ReviewListProps {
  newReview: Review | null;
  sortBy: 'date' | 'rating';
  sortOrder: 'asc' | 'desc';
}

const ReviewList: React.FC<ReviewListProps> = ({ newReview, sortBy, sortOrder }) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filteredReviews, setFilteredReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState<string>("");
  
  // New: deletion modal state
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [reviewToDelete, setReviewToDelete] = useState<Review | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        const reviewsData = await getReviews();
        setReviews(reviewsData);
      } catch (err) {
        console.error('Error fetching reviews:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchReviews();
  }, [newReview]);
  useEffect(() => {
    let filtered = [...reviews];

    // Sort reviews using props sortBy/sortOrder
    filtered.sort((a, b) => {
      if (sortBy === 'date') {
        const dateA = new Date(a.created_at).getTime();
        const dateB = new Date(b.created_at).getTime();
        return sortOrder === 'desc' ? dateB - dateA : dateA - dateB;
      } else {
        return sortOrder === 'desc' 
          ? b.predicted_rating - a.predicted_rating 
          : a.predicted_rating - b.predicted_rating;
      }
    });

    setFilteredReviews(filtered);
  }, [reviews, sortBy, sortOrder]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };


  const getSentimentColor = (score: number) => {
    if (score >= 0.6) return '#007600';
    if (score >= 0.4) return '#b7aa00';
    return '#b12704';
  };

  // Add helper: small SVG placeholder (data URL)
	const placeholderSvg = `data:image/svg+xml;utf8,${encodeURIComponent(
		'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="100%" height="100%" fill="#efefef"/><text x="50%" y="50%" fill="#999" font-size="20" font-family="Arial" text-anchor="middle" dy=".3em">Image unavailable</text></svg>'
	)}`;

  // Use explicit backend origin or env var to point to backend media directory
  const MEDIA_URL = (process.env.REACT_APP_MEDIA_URL || `${BACKEND_ORIGIN}/media`).replace(/\/+$/, '');

	// Resolve image source strings coming from backend, serving from backend media folder when appropriate
	const getImageSrc = (raw: string | undefined | null) => {
    const imgStr = (raw || '').trim();
    console.debug('[ReviewList] raw image string:', raw);
		if (!imgStr) return placeholderSvg;

		// already a data URL
		if (imgStr.startsWith('data:')) return imgStr;

		// absolute http(s) or protocol-relative //host/path
    if (/^https?:\/\//i.test(imgStr)) {
      console.debug('[ReviewList] resolved absolute URL:', imgStr);
      return imgStr;
    }
    if (/^\/\//.test(imgStr)) {
      const resolved = `${window.location.protocol}${imgStr}`;
      console.debug('[ReviewList] resolved protocol-relative URL:', resolved);
      return resolved;
    }

		// paths already pointing to /media or media/ -> normalize to MEDIA_URL
    if (/^\/?media\//i.test(imgStr)) {
      const resolved = `${MEDIA_URL}/${imgStr.replace(/^\/+media\/?/i, '')}`;
      console.debug('[ReviewList] resolved media URL:', resolved);
      return resolved;
    }

		// If the backend returned just a filename (no slashes) -> assume it's stored in media
    if (!imgStr.includes('/')) {
      const resolved = `${MEDIA_URL}/${imgStr}`;
      console.debug('[ReviewList] resolved filename to media URL:', resolved);
      return resolved;
    }

		// If it's a relative path (contains slashes but no protocol), treat it as relative inside media
    const resolved = `${MEDIA_URL}/${imgStr.replace(/^\/+/, '')}`;
    console.debug('[ReviewList] resolved relative path to media URL:', resolved);
    return resolved;
	};

  const openDeleteModal = (review: Review) => {
    setReviewToDelete(review);
    setDeleteModalOpen(true);
  };
  
  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setReviewToDelete(null);
    setDeleting(false);
  };
  
  const confirmDelete = async () => {
    if (!reviewToDelete) return;
    setDeleting(true);
    try {
      await deleteReview(reviewToDelete.id);
      setReviews(prev => prev.filter(r => r.id !== reviewToDelete.id));
      closeDeleteModal();
    } catch (err) {
      console.error('Delete error', err);
      // keep modal open and stop loading; UI could show error if desired
      setDeleting(false);
      alert('Error deleting review');
    }
  };

  return (
    <div className="review-list-container">
      <div className="reviews-content">
        {filteredReviews.length === 0 ? (
          <div className="no-reviews">
            <p>{reviews.length === 0 ? 'No reviews yet.' : 'No reviews match your filters.'}</p>
          </div>
        ) : (
          <div className="reviews-list">
            {filteredReviews.map((review, index) => (
              <div key={review.id} className="review-item">
                {/* delete button placed to the right of the card */}
                <button
                  type="button"
                  className="delete-card-button"
                  onClick={() => openDeleteModal(review)}
                  aria-label="Delete review"
                >
                  Delete
                </button>
                <div className="review-header">
                  <div className="reviewer-name">
                    {review.reviewerName || 'Anonymous Customer'}
                  </div>
                  <div className="review-stars">
                    <Stars rating={review.predicted_rating} />
                  </div>
                </div>
                
                <div className="review-content">
                  {editingId === review.id ? (
                    <textarea
                      className="edit-textarea"
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      rows={4}
                    />
                  ) : (
                    <>
                      <p className="review-text">{review.text}</p>
                      {review.images && review.images.length > 0 && (
                        <div className="review-images">
                          {review.images.map((img, imgIndex) => {
                            const src = getImageSrc(img.image);
                            return (
                              <img
                                key={img.id}
                                src={src}
                                alt={`review-${review.id}-img-${imgIndex}`}
                                className="review-thumb"
                                loading="lazy"
                                onLoad={() => console.debug('[ReviewList] image loaded:', src, 'for review', review.id)}
                                onError={(e) => {
                                  console.error('[ReviewList] image failed to load:', src, 'for review', review.id, e);
                                  // avoid infinite loop if placeholder fails
                                  (e.currentTarget as HTMLImageElement).onerror = null;
                                  (e.currentTarget as HTMLImageElement).src = placeholderSvg;
                                }}
                              />
                            );
                          })}
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                <div className="review-footer">
                  <div className="review-date">Reviewed on {formatDate(review.created_at)}</div>
                  <div className="review-actions">
                    {(() => {
                      // prefer backend-provided sentiment label if present
                      const backendSentiment = (review as any).sentiment;
                      const score = review.sentiment_score;
                      const derived = typeof score === 'number'
                        ? (score >= 0.6 ? 'Positive' : score >= 0.4 ? 'Neutral' : 'Negative')
                        : 'Unknown';
                      const label = backendSentiment || derived;
                      return (
                        <span
                          className="sentiment-score"
                          style={{ color: getSentimentColor(typeof score === 'number' ? score : 0) }}
                        >
                          Sentiment: {label}
                        </span>
                      );
                    })()}

                     <div className="action-buttons">
                       {editingId === review.id ? (
                         <>
                           <button
                             className="save-btn"
                             onClick={async () => {
                               try {
                                 const updated = await updateReview(review.id, editText);
                                 setReviews(prev => prev.map(r => r.id === updated.id ? updated : r));
                                 setEditingId(null);
                                 setEditText('');
                               } catch (err) {
                                 console.error('Update error', err);
                                 alert('Error updating review');
                               }
                             }}
                           >
                             Save
                           </button>
                           <button
                             className="cancel-btn"
                             onClick={() => { setEditingId(null); setEditText(''); }}
                           >
                             Cancel
                           </button>
                         </>
                       ) : (
                         <>
                          <button
                            className="edit-btn"
                            onClick={() => { setEditingId(review.id); setEditText(review.text); }}
                          >
                            Edit
                          </button>
                         </>
                       )}
                     </div>
                   </div>
                 </div>
               </div>
             ))}
           </div>
         )}
       </div>

      {/* Delete confirmation modal */}
      {deleteModalOpen && reviewToDelete && (
        <div className="confirm-modal-overlay" role="dialog" aria-modal="true">
          <div className="confirm-modal" onClick={(e) => e.stopPropagation()}>
            <div className="confirm-modal-header">
              <h3>Delete review</h3>
            </div>
            <div className="confirm-modal-body">
              <p>Are you sure you want to delete this review by <strong>{reviewToDelete.reviewerName || 'Anonymous'}</strong>?</p>
              <p className="confirm-review-text">"{String(reviewToDelete.text).slice(0, 200)}{reviewToDelete.text.length > 200 ? '…' : ''}"</p>
            </div>
            <div className="confirm-modal-actions">
              <button className="modal-cancel-btn" onClick={closeDeleteModal} disabled={deleting}>Cancel</button>
              <button className="confirm-delete-btn" onClick={confirmDelete} disabled={deleting}>
                {deleting ? 'Deleting...' : 'Delete review'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};



export default ReviewList;
