import React, { useState, useEffect, useRef } from "react";
import { submitReview, getReviews } from "../api";
import { Review } from '../types';
import Stars from "./Stars";
import './ReviewForm.css';

interface ReviewFormProps {
  onNewReview: (review: Review) => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ onNewReview }) => {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const reviewsData = await getReviews();
        setReviews(reviewsData);
      } catch (err) {
        console.error('Error fetching reviews:', err);
      }
    };
    fetchReviews();
  }, []);

  const calculateAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.predicted_rating, 0);
    return sum / reviews.length;
  };

  const getRatingDistribution = () => {
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    reviews.forEach(review => {
      const roundedRating = Math.round(review.predicted_rating);
      if (roundedRating >= 1 && roundedRating <= 5) {
        distribution[roundedRating as keyof typeof distribution]++;
      }
    });
    return distribution;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    
    setLoading(true);
    setErrorMessage(null);
    try {
      console.debug('[ReviewForm] submitting review text length:', text.length, 'images count:', images.length);
      images.forEach((f, i) => console.debug('[ReviewForm] image file:', i, f.name, f.size, f.type));
      // Always pass the images array (may be empty) so backend receives a consistent payload
      const review = await submitReview(text, images);
      onNewReview(review);
      setReviews(prev => [...prev, review]); 
      setText("");
      setImages([]);
      setImagePreviews([]);
      setShowModal(false); 
    } catch (err) {
      console.error(err);
      // Try to extract backend error message for 400 responses
      const maybeResponse = (err as any)?.response;
      if (maybeResponse && maybeResponse.status === 400 && maybeResponse.data) {
        const msg = maybeResponse.data.error || JSON.stringify(maybeResponse.data);
        setErrorMessage(String(msg));
      } else {
        setErrorMessage('Error submitting review');
      }
    }
    setLoading(false);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) {
      // user cleared selection -> clear images and previews explicitly
      setImages([]);
      setImagePreviews(prev => {
        // revoke any existing preview URLs
        prev.forEach(url => { try { URL.revokeObjectURL(url); } catch(e){/*ignore*/} });
        return [];
      });
      return;
    }
    const arr = Array.from(files);
    console.debug('[ReviewForm] selected files count:', arr.length, arr.map(f => f.name));
    setImages(arr);
    const previews = arr.map(file => {
      const obj = URL.createObjectURL(file);
      console.debug('[ReviewForm] created preview URL:', obj, 'for file', file.name);
      return obj;
    });
    // revoke previous previews before setting new ones
    setImagePreviews(prev => {
      prev.forEach(url => { try { URL.revokeObjectURL(url); } catch(e){/*ignore*/} });
      return previews;
    });
  };

  const removeImageAt = (idx: number) => {
    setImages(prev => {
      const next = prev.filter((_, i) => i !== idx);
      return next;
    });
    setImagePreviews(prev => {
      const p = prev.slice();
      // revoke object URL for removed preview if exists
      if (p[idx]) {
        try { URL.revokeObjectURL(p[idx]); } catch(e){/*ignore*/ }
      }
      p.splice(idx, 1);
      return p;
    });
  };

  // New: small menu-dot component to be used in review items.
  // Use: import { ReviewMenu } from './ReviewForm'; then render <ReviewMenu onDelete={...} />
  interface ReviewMenuProps {
    onDelete: () => void;
    ariaLabel?: string;
  }
  
  const ReviewMenu: React.FC<ReviewMenuProps> = ({ onDelete, ariaLabel = "Open review menu" }) => {
    const [open, setOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
      const onDocClick = (e: MouseEvent) => {
        if (!containerRef.current) return;
        if (!containerRef.current.contains(e.target as Node)) {
          setOpen(false);
        }
      };
      document.addEventListener('click', onDocClick);
      return () => document.removeEventListener('click', onDocClick);
    }, []);

    return (
      <div className="menu-container" ref={containerRef} onClick={(e) => e.stopPropagation()}>
        <button
          type="button"
          className="menu-dot-button"
          aria-label={ariaLabel}
          onClick={() => setOpen(v => !v)}
        >
          ⋯
        </button>
        {open && (
          <div className="menu-dropdown" role="menu">
            <button
              type="button"
              className="delete-review-btn"
              role="menuitem"
              onClick={() => { setOpen(false); onDelete(); }}
            >
              Delete review
            </button>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="review-form-container">
      {reviews.length > 0 && (
        <div className="average-rating-section">
          <h1>Customer Reviews</h1>
          <div className="average-rating-summary">
            <Stars rating={calculateAverageRating()} />
            <span className="average-number">
              {calculateAverageRating().toFixed(1)} out of 5
            </span>
            <span className="total-reviews">
              {reviews.length} global rating{reviews.length !== 1 ? 's' : ''}
            </span>
          </div>
          
          <div className="rating-distribution">
            {[5, 4, 3, 2, 1].map(star => {
              const distribution = getRatingDistribution();
              const count = distribution[star as keyof typeof distribution];
              const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
              
              return (
                <div key={star} className="rating-bar">
                  <span className="star-label">{star} star</span>
                  <div className="bar-container">
                    <div 
                      className="bar-fill" 
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                  <span className="count-label">{count}</span>
                </div>
              );
            })}
          </div>
          
          <div className="review-this-product">
            <h3>Review this product</h3>
            <p>Share your thoughts with other customers</p>
            <button 
              className="share-review-btn"
              onClick={() => setShowModal(true)}
            >
              Write a customer review
            </button>
          </div>
        </div>
      )}
      
      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Write a Customer Review</h2>
              <button 
                className="close-modal-btn"
                onClick={() => setShowModal(false)}
              >
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit} className="modal-review-form">
              <div className="form-group">
                <textarea
                  placeholder="Write your review here..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  required
                  rows={6}
                  className="modal-review-textarea"
                />
              </div>
              <div className="form-group">
                <label htmlFor="images">Add images (optional)</label>
                <input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageChange}
                />
                <div className="image-previews">
                  {imagePreviews.map((src, idx) => (
                    <div key={idx} className="preview-item">
                      <img src={src} alt={`preview-${idx}`} />
                      <button type="button" onClick={() => removeImageAt(idx)}>Remove</button>
                    </div>
                  ))}
                </div>
              </div>

              {errorMessage && (
                <div className="form-error">
                  {errorMessage}
                </div>
              )}
              <div className="modal-actions">
                <button 
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="cancel-btn"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={loading || !text.trim()}
                  className="submit-modal-btn"
                >
                  {loading ? "Analyzing..." : "Submit Review"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewForm;
