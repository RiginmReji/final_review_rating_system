export interface Review {
  id: number;
  text: string;
  predicted_rating: number;
  sentiment_score: number;
  created_at: string;
  reviewerName?: string;
  images?: Array<{
    id: number;
    image: string; // full URL to the image
  }>;
}